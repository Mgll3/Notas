/**
 * Spring Framework configuration files.
 */
package ingresos.config;
