/**
 * JPA domain objects.
 */
package ingresos.domain;
