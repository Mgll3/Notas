/**
 * Service layer beans.
 */
package ingresos.service;
