/**
 * Data Transfer Objects.
 */
package ingresos.service.dto;
