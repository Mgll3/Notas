/**
 * Spring Security configuration.
 */
package ingresos.security;
