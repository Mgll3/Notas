/**
 * Spring MVC REST controllers.
 */
package ingresos.web.rest;
