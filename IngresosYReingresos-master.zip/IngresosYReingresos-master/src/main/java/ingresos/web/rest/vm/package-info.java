/**
 * View Models used by Spring MVC REST controllers.
 */
package ingresos.web.rest.vm;
