/**
 * Spring Data JPA repositories.
 */
package ingresos.repository;
